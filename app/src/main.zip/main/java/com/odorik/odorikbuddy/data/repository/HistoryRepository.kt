package com.odorik.odorikbuddy.data.repository

import com.odorik.odorikbuddy.data.remote.OdorikApi
import com.odorik.odorikbuddy.model.HistoryItem
import javax.inject.Inject

/**
 * Repository for fetching call and SMS history from the Odorik API.
 */
class HistoryRepository @Inject constructor(private val apiService: OdorikApi) {

    /**
     * Fetches both call and SMS history, combines them, and sorts them by date.
     */
    suspend fun getCombinedHistory(user: String, pass: String, from: String, to: String): List<HistoryItem> {
        // Fetch calls and SMS in parallel
        val calls = apiService.getCallHistory(user, pass, from, to)
        val sms = apiService.getSmsHistory(user, pass, from, to)
        
        // Combine the two lists and sort them with the newest items first.
        return (calls + sms).sortedByDescending { it.date }
    }
}
