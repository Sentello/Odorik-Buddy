package com.odorik.odorikbuddy.domain.usecase

import com.odorik.odorikbuddy.data.remote.OdorikApi
// import com.odorik.odorikbuddy.data.model.RpcRequest // Commented out
import com.odorik.odorikbuddy.data.model.UserInfo
import com.odorik.odorikbuddy.data.repository.UserRepository
import javax.inject.Inject
// import com.google.gson.Gson // Commented out

class GetUserInfoUseCase @Inject constructor(
    private val odorikApi: OdorikApi,
    private val userRepository: UserRepository
) {
    // Commented out the execute method for now
    /*
    suspend fun execute(): Result<UserInfo> {
        val userId = userRepository.getUserId()
        val password = userRepository.getPassword()

        if (userId == null || password == null) {
            return Result.failure(Exception("User not logged in"))
        }

        return try {
            val response = odorikApi.getUserInfo(RpcRequest("get_user_info", listOf(userId, password)))
            if (response.result != null) {
                // Convert JsonElement to UserInfo using Gson
                val gson = Gson()
                val userInfo = gson.fromJson(response.result, UserInfo::class.java)
                Result.success(userInfo)
            } else {
                Result.failure(Exception(response.error ?: "Unknown error"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    */
}