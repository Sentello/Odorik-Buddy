package com.odorik.odorikbuddy.model

import com.google.gson.annotations.SerializedName

// Represents a single item in the call or SMS history.
// Using @SerializedName for robust JSON parsing with Gson.
data class HistoryItem(
    @SerializedName("id")
    val id: String,
    @SerializedName("date")
    val date: String,
    @SerializedName("direction")
    val direction: String,
    @SerializedName("source_number")
    val source_number: String,
    @SerializedName("destination_number")
    val destination_number: String,
    @SerializedName("length")
    val length: Int?, // Nullable because SMS records do not have a length
    @SerializedName("price")
    val price: Double,
    @SerializedName("status")
    val status: String? // Nullable because SMS records do not have a status
)
